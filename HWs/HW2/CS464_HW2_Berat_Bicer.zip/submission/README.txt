Write each question to different file, namely question1, 2, 3 etc.
Then, simply type to console

python question1.py

Note that you need Numpy, Matplotlib, and Scikit installed in your Python 3 environment. 
I assumed you have Python 3 as your default Python interpreter, which is called when the line above is typed.