From terminal, cd into the directory where "source.py" file is located. Then, simply type

python source.py

Note that you need Numpy installed in your Python 3 environment. 
I assumed you have Python 3 as your default Python interpreter, which is called when the line above is typed.